<a href="https://wa.me/918309569385" class="float wp-icon fadeInUp" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>

<a href="https://www.facebook.com/Soft2Techno?mibextid=LQQJ4d" class="float fb-icon fadeInUp" target="_blank">
<i class="fa fa-facebook my-float"></i>
</a>

<a href="https://instagram.com/soft2technologiesweb?igshid=YmMyMTA2M2Y=" class="float insta-icon fadeInUp" target="_blank">
<i class="fa fa-instagram my-float"></i>
</a>

<a href="https://www.linkedin.com/company/soft2technologies/" class="float linkedin-icon fadeInUp" target="_blank">
<i class="fa fa-linkedin my-float"></i>
</a>
