<html>
    <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/S2T.png" alt="">
        <span>Soft2Technologies</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About</a></li>
          <li><a class="nav-link scrollto" href="services.php">Services</a></li>
          <!-- <li><a class="nav-link scrollto" href="#">Projects</a></li> -->
          <!-- <li><a class="nav-link scrollto" href="#team">Careers</a></li> -->
          <!-- <li><a href="blog.html">Blog</a></li> -->
          <li class="dropdown"><a href="#"><span>Careers</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="#">Careers</a></li> -->
              <li><a href="courses.php">Courses</a></li>
              <!-- <li class="dropdown"><a href="#"><span>Courses</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Full-Stack web Developement</a></li>
                  <li><a href="#">Flutter</a></li>
                  <li><a href="#">Digital Marketing</a></li>
                  <li><a href="#">More..</a></li>
                </ul>
              </li> -->
            </ul>
          </li>
          <!-- <li><a class="nav-link scrollto" href="#contact">Contact</a></li> -->
          <li><a class="getstarted scrollto" href="contact-us.php">Contact Us</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>

  
  </html>