https://soft2technologies.com/

All Bootstrap and Css links => link.php
All js cdn => linkjs.php

// Assests Folder holds all the css, js files required along with the images and shapes, also all the required 
// assets could be found in the same folder.

<!-- Note :- linkjs must be included below footer same as JS files are included in Project code. -->

Navbar => header.php
Footer => footer.php
Home Page => index.php
Contact Page => contact-us.php (contact.php => code for contact for in php)
Service Page => services.php
socio-icon => socio-icons.php (Social Icons fade up code) // css file => con-icon.css 


